//@eliashedamo
# Twitter clone

### Fully functional Django website that works exactly like real Twitter<br>

##### Home page
![home page](screens/home.png) <br><br>
##### Tweet page
![tweet page](screens/post.png)<br><br>
##### Search results page
![search page](screens/search.png)<br><br>
##### Search results page
![search page](screens/search2.png)<br><br>
##### User's page
![settings page](screens/user.png)<br><br>
##### User's settings page
![settings page](screens/settings.png)<br><br>
##### Sign in page
![settings page](screens/signin.png)<br><br>
##### Sign up page
![settings page](screens/signup.png)<br><br>
 
### TODO
- [ ] Add mobile friendly template
- [ ] Like functionality
- [ ] 'Update and delete tweets by user' functionality




